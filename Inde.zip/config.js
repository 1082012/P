module.exports = {
  BOT_TOKEN:
  "8346533169:AAFDjh0thf8ctIjnoDCbcXmYkm0etPb0bQQ",
};